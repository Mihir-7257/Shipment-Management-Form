const DB_NAME = "deliveryDB";
const RELATION_NAME = "Shipment-table";
const BASE_URL = "https://login2explore.com:5577";
const JPDB_IRL = "/api/irl";  
const JPDB_IML = "/api/iml";  
const TOKEN = "764066463|7385821598501969265|764067399";
